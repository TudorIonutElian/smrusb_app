<template>

</template>

<script>
export default {
    name: "AdminNav.vue"
}
</script>

<style scoped>

</style>
