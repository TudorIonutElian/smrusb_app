<template>
    <div class="container mt-3 p-3 bg-danger text-white">
        <div class="row">
            <div class="col-12">
                Nu aveti acces, va rugam sa solicitati acest acces administratorului de sistem!
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "NoAcces.vue"
}
</script>

<style scoped>

</style>
